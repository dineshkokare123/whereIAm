//
//  ViewController.swift
//  IOSDay12ForwardGeo
//
//  Created by Felix-ITS 012 on 16/08/18.
//  Copyright © 2018 felix. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController,MKMapViewDelegate,UITextFieldDelegate {

    @IBOutlet weak var searchText: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        searchText.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func changeMapType(_ sender: UISegmentedControl) {
        
        switch segment.selectedSegmentIndex {
        case 0: mapView.mapType = MKMapType.standard
        case 1: mapView.mapType = MKMapType.satellite
        case 2: mapView.mapType = MKMapType.hybrid
        case 3: mapView.mapType = MKMapType.hybridFlyover
        case 4: mapView.mapType = MKMapType.satelliteFlyover
        default: mapView.mapType = MKMapType.standard
            
            
        }
    }
    @IBOutlet weak var segment: UISegmentedControl!
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let geo = CLGeocoder()
        geo.geocodeAddressString(searchText.text!) { (placeMarks, error) in
            let placeMark = placeMarks?.first!
            let coOrdinate:CLLocationCoordinate2D? =     placeMark?.location?.coordinate
          
            let span = MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1)
            let region = MKCoordinateRegion(center: coOrdinate!, span: span)
            self.mapView.setRegion(region, animated: true)
            let Point = MKPointAnnotation()
            Point.coordinate = coOrdinate!
            self.mapView.addAnnotation(Point)
            textField.resignFirstResponder()
            
            
           
            
        }
        
        
        return true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

