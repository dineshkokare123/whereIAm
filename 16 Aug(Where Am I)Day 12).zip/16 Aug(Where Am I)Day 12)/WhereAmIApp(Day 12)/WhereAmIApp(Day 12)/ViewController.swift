//
//  ViewController.swift
//  WhereAmIApp(Day 12)
//
//  Created by Student016 on 16/08/18.
//  Copyright © 2018 ra. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
class ViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate {

    @IBOutlet weak var mymapview: MKMapView!
    var locationManager=CLLocationManager()
    
    @IBAction func DetectingLocation(_ sender: UIButton) {
        
        startDetectingLocation()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func startDetectingLocation() {
        locationManager.desiredAccuracy=kCLLocationAccuracyBest
        locationManager.delegate=self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let currentLocation = locations.last
        if(currentLocation != nil)
        {
            manager.stopUpdatingLocation()
        }
        
        
        let coOrdinate:CLLocationCoordinate2D=(currentLocation?.coordinate)!
        let latitude=coOrdinate.latitude
        let longitude = coOrdinate.longitude
        print("Lattitude:\(latitude) and Longitude:\(longitude)")        
        let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        let region = MKCoordinateRegion(center: coOrdinate, span: span)
        mymapview.setRegion(region, animated: true)
        let mkpoint=MKPointAnnotation()
        mkpoint.coordinate=coOrdinate
        mymapview.addAnnotation(mkpoint)
        let location = CLLocation(latitude: latitude, longitude: longitude)
        // to get details when arrow points to pin
        
        let geo = CLGeocoder()
        geo.reverseGeocodeLocation(location) { (placemarks, error) in
            let placemark = placemarks?.first
            print("Name:\(String(describing: placemark?.name)), Country:\(String(describing: placemark?.country)) and locality:\(String(describing: placemark?.locality)) throughfar:\(String(describing: placemark?.thoroughfare))")
            mkpoint.title=placemark?.name
        }
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

