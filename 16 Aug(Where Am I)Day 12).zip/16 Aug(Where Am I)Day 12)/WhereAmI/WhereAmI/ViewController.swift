//
//  ViewController.swift
//  WhereAmI
//
//  Created by Mac on 16/08/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
class ViewController: UIViewController,MKMapViewDelegate,CLLocationManagerDelegate {

    @IBAction func ChangeMapType(_ sender: UISegmentedControl) {
        
        switch mysegment.selectedSegmentIndex {
        case 0:
            mymapview.mapType = .standard
        case 1:
            mymapview.mapType = .satellite
        case 2:
            mymapview.mapType = .hybrid
        default:
            mymapview.mapType = .standard
        }
        
        
    }
    @IBOutlet weak var mysegment: UISegmentedControl!
    @IBOutlet weak var mymapview: MKMapView!
    let locationmanager=CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func DetectLocation(_ sender: UIButton) {
        startdetectinglocation()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
func startdetectinglocation()
{
    locationmanager.delegate=self
    locationmanager.desiredAccuracy=kCLLocationAccuracyBest
    locationmanager.requestWhenInUseAuthorization()
    locationmanager.startUpdatingLocation()
    
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let currentlocation=locations.last
        let coOrdinate:CLLocationCoordinate2D=(currentlocation?.coordinate)!
        let latitute=coOrdinate.latitude
        let longitude=coOrdinate.longitude
        print("Latitude:\(latitute) and Longitude:\(longitude)")
        mymapview.showsUserLocation=true
        
        //for zooming
        
        let span:MKCoordinateSpan=MKCoordinateSpanMake(0.01, 0.01)
        let region=MKCoordinateRegionMake(coOrdinate, span)
        mymapview.setRegion(region, animated: true)
        // to show point
        let mkpoint=MKPointAnnotation()
        mkpoint.coordinate=coOrdinate
        mymapview.addAnnotation(mkpoint)
        
        // To show Details
        let location=CLLocation(latitude: latitute, longitude: longitude)
        let geo=CLGeocoder()
        geo.reverseGeocodeLocation(location) { (placemarks, error) in
            let placemark=placemarks?.first
            print("Name:\(placemark?.name) Country:\(placemark?.country)")
            var detail = (placemark?.name)!+(placemark?.country)!
            mkpoint.title=detail
            
        }
        
        
    }
    
    
    
}

